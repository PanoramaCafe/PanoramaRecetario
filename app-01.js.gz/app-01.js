
    // Wrapper a prueba de fallos para Safari en iPad (evita SecurityError en file://)
    const memoryStorage = {};
    const safeStorage = {
      getItem: function(key) {
        try {
          return localStorage.getItem(key);
        } catch(e) {
          return memoryStorage[key] || null;
        }
      },
      setItem: function(key, val) {
        try {
          localStorage.setItem(key, val);
        } catch(e) {
          memoryStorage[key] = val;
        }
      }
    };

    // REGISTRO DE SERVICE WORKER EMBEBIDO (PWA OFFLINE READY)
    if ('serviceWorker' in navigator) {
      const swCode = `
        const CACHE_NAME = 'recetario-pwa-v1';
        self.addEventListener('install', (e) => self.skipWaiting());
        self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
        self.addEventListener('fetch', (e) => e.respondWith(fetch(e.request).catch(() => caches.match(e.request))));
      `;
      const blob = new Blob([swCode], { type: 'application/javascript' });
      const swUrl = URL.createObjectURL(blob);
      navigator.serviceWorker.register(swUrl).catch(function(err) {
        console.log('SW offline registration:', err);
      });
    }

    // Datos iniciales y recuperación segura. La versión original referenciaba
    // `defaultData` sin declararlo, lo que detenía TODO el JavaScript al cargar.
    const defaultData = {
      insumos: [],
      recetas: [],
      comprasGuardadas: []
    };

    function loadAppState() {
      try {
        const raw = safeStorage.getItem('recetario_pro_data_v5');
        if (!raw) return JSON.parse(JSON.stringify(defaultData));
        const parsed = JSON.parse(raw);
        return {
          insumos: Array.isArray(parsed.insumos) ? parsed.insumos : [],
          recetas: Array.isArray(parsed.recetas) ? parsed.recetas : [],
          comprasGuardadas: Array.isArray(parsed.comprasGuardadas) ? parsed.comprasGuardadas : []
        };
      } catch (e) {
        console.warn('Datos locales inválidos; se inicia con estructura vacía.', e);
        return JSON.parse(JSON.stringify(defaultData));
      }
    }

    let appState = loadAppState();
    appState.insumos = (appState.insumos || []).map(function(ins){
      if (ins.aprovechamiento === undefined) ins.aprovechamiento = Math.max(0, 100 - (Number(ins.merma)||0));
      const compra = String(ins.unidadCompra || '').toLowerCase();
      const rawUnit = String(ins.unidadBase || '').toLowerCase();
      // Normaliza registros antiguos/importados que guardaron L o kg como unidad de uso.
      // El Recetario trabaja siempre en ml, g o pza para que 150 ml se cobre como 150 ml.
      if (compra === 'l' && ['l','lt','litro','litros'].includes(rawUnit)) {
        if (isFinite(Number(ins.costoPorUnidadUso))) ins.costoPorUnidadUso = Number(ins.costoPorUnidadUso) / 1000;
        ins.unidadBase = 'ml';
      } else if (compra === 'kg' && ['kg','kilogramo','kilogramos'].includes(rawUnit)) {
        if (isFinite(Number(ins.costoPorUnidadUso))) ins.costoPorUnidadUso = Number(ins.costoPorUnidadUso) / 1000;
        ins.unidadBase = 'g';
      } else {
        ins.unidadBase = getInsumoUnidadBase(ins);
      }
      return ins;
    });
    // Persistir la normalización para que no vuelva a aparecer el precio por litro/kilo.
    try { safeStorage.setItem('recetario_pro_data_v5', JSON.stringify(appState)); } catch(e) {}
    let currentRecipeIngredients = [];
    let editingRecipeId = null;
    let currentPurchaseList = [];

    function saveToStorage() {
      safeStorage.setItem('recetario_pro_data_v5', JSON.stringify(appState));
      updateSummaryCounts();
    }

    function switchTab(tabId) {
      document.querySelectorAll('.tab-content').forEach(function(el) { el.classList.remove('active'); });
      document.querySelectorAll('.nav-btn').forEach(function(el) { el.classList.remove('active'); });
      
      const tabEl = document.getElementById('tab-' + tabId);
      if (tabEl) tabEl.classList.add('active');
      
      const btnEl = document.getElementById('btn-tab-' + tabId);
      if (btnEl) btnEl.classList.add('active');

      if (tabId === 'matriz') renderBCGMatrix();
      if (tabId === 'analisis') renderAnalysis();
      if (tabId === 'insumos') renderInsumos();
      if (tabId === 'recetas') { renderInsumoOptions(); renderRecipeIngredientsTable(); }
      if (tabId === 'import-export') updateSummaryCounts();
    }

    function updateSummaryCounts() {
      if (document.getElementById('stat-count-insumos')) {
        document.getElementById('stat-count-insumos').innerText = appState.insumos.length;
        document.getElementById('stat-count-recetas').innerText = appState.recetas.length;
      }
    }

    // --- MÓDULO 1: INSUMOS & PROVEEDORES ---
    function getInsumoUnitCost(ins) {
      if (!ins) return 0;
      if (ins.costoModo === 'directo' && isFinite(Number(ins.costoDirecto))) return Number(ins.costoDirecto) || 0;
      if (ins.costoPorUnidadUso !== undefined && isFinite(Number(ins.costoPorUnidadUso))) return Number(ins.costoPorUnidadUso) || 0;
      const purchase = Number(ins.costoCompra) || 0;
      const contenido = Number(ins.contenidoPresentacion || ins.contenido || 0);
      const unidades = Math.max(1, Number(ins.unidadesPorCompra || ins.unitsPerPurchase || 1));
      const factor = Number(ins.factor) || ((String(ins.unidadCompra || '').toLowerCase() === 'kg' || String(ins.unidadCompra || '').toLowerCase() === 'l') ? 1000 : 1);
      const base = contenido > 0 ? purchase / (unidades * contenido * factor) : purchase / (unidades * factor);
      const aprovechamiento = Math.max(0.0001, Math.min(1, (Number(ins.aprovechamiento ?? (100 - Number(ins.merma || 0)))) / 100));
      return base / aprovechamiento;
    }

    function getInsumoAprovechamiento(ins) {
      if (!ins) return 100;
      if (ins.aprovechamiento !== undefined) return Number(ins.aprovechamiento) || 0;
      return Math.max(0, 100 - (Number(ins.merma) || 0));
    }

    function getInsumoUnidadBase(ins) {
      const raw = String(ins?.unidadBase || '').trim().toLowerCase();
      const compra = String(ins?.unidadCompra || '').trim().toLowerCase();
      if (raw === 'kg' || raw === 'kilogramo' || raw === 'kilogramos' || compra === 'kg') return 'g';
      if (raw === 'l' || raw === 'lt' || raw === 'litro' || raw === 'litros' || compra === 'l') return 'ml';
      if (raw === 'ml' || raw === 'mililitro' || raw === 'mililitros') return 'ml';
      if (raw === 'g' || raw === 'gramo' || raw === 'gramos') return 'g';
      return raw || 'pza';
    }

    function renderInsumoOptions() {
      const select = document.getElementById('rec-select-insumo');
      if (!select) return;
      const search = (document.getElementById('rec-search-insumo')?.value || '').trim().toLowerCase();
      const current = select.value;
      const list = appState.insumos.slice().sort((a,b) => String(a.nombre||'').localeCompare(String(b.nombre||''),'es',{sensitivity:'base'}))
        .filter(ins => !search || String(ins.nombre||'').toLowerCase().includes(search) || String(ins.categoria||'').toLowerCase().includes(search));
      select.innerHTML = '<option value="">-- Seleccionar ingrediente --</option>' + list.map(ins => '<option value="'+ins.id+'">'+ins.nombre+' — $'+getInsumoUnitCost(ins).toFixed(4)+'/'+getInsumoUnidadBase(ins)+'</option>').join('');
      if (list.some(x => x.id === current)) select.value = current;
      updateSelectedInsumoInfo();
    }

    function updateSelectedInsumoInfo() {
      const id = document.getElementById('rec-select-insumo')?.value;
      const ins = appState.insumos.find(i => i.id === id);
      const info = document.getElementById('rec-selected-insumo-info');
      const cost = document.getElementById('rec-selected-insumo-cost');
      if (!ins) { if(info) info.innerText=''; if(cost) cost.innerText='$0.0000 / unidad'; return; }
      const unit = getInsumoUnidadBase(ins), unitCost = getInsumoUnitCost(ins), appr = getInsumoAprovechamiento(ins);
      if(info) info.innerText = (ins.costoModo === 'directo' ? 'Costo directo' : (ins.costoModo === 'inventario' ? 'Costo tomado de Panorama Inventario' : 'Costo derivado de presentación')) + ' · '+appr.toFixed(1)+'% aprovechamiento · unidad: '+unit;
      if(cost) cost.innerText = '$'+unitCost.toFixed(4)+' / '+unit;
    }

    function renderInsumos() {
      const tbody = document.getElementById('insumos-list-table');
      if (!tbody) return;
      const search = (document.getElementById('ins-search')?.value || '').trim().toLowerCase();
      const cat = document.getElementById('filter-ins-categoria')?.value || 'TODAS';
      const list = appState.insumos.slice().sort((a,b)=>String(a.nombre||'').localeCompare(String(b.nombre||''),'es',{sensitivity:'base'})).filter(ins =>
        (cat==='TODAS'||ins.categoria===cat) && (!search || String(ins.nombre||'').toLowerCase().includes(search) || String(ins.proveedor||'').toLowerCase().includes(search))
      );
      tbody.innerHTML = list.length ? list.map(ins => '<tr><td><strong>'+ins.nombre+'</strong></td><td><span class="badge badge-neutral">'+(ins.categoria||'Otros')+'</span></td><td>'+(ins.proveedor||'—')+'</td><td class="font-mono">'+getInsumoUnidadBase(ins)+'</td><td class="font-mono" style="text-align:right;font-weight:700">$'+getInsumoUnitCost(ins).toFixed(4)+'</td><td class="font-mono" style="text-align:center">'+getInsumoAprovechamiento(ins).toFixed(1)+'%</td><td style="text-align:center"><button class="btn btn-secondary btn-sm" onclick="editInsumo(\''+ins.id+'\')">Editar</button> <button class="btn btn-danger btn-sm" onclick="deleteInsumo(\''+ins.id+'\')">🗑️</button></td></tr>').join('') : '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:1.5rem">No hay insumos que coincidan.</td></tr>';
      renderInsumoOptions();
    }

    function toggleDirectCostFields() {
      const direct = document.getElementById('ins-costo-tipo')?.value === 'directo';
      if(document.getElementById('ins-directo-wrap')) document.getElementById('ins-directo-wrap').style.display = direct ? '' : 'none';
      if(document.getElementById('ins-compra-wrap')) document.getElementById('ins-compra-wrap').style.display = direct ? 'none' : '';
      if(document.getElementById('ins-contenido-wrap')) document.getElementById('ins-contenido-wrap').style.display = direct ? 'none' : '';
    }

    function resetInsumoForm() {
      ['ins-edit-id','ins-nombre','ins-proveedor','ins-contacto-prov','ins-costo','ins-contenido','ins-costo-directo'].forEach(id=>{const e=document.getElementById(id); if(e)e.value='';});
      document.getElementById('ins-costo-tipo').value='conversion';
      document.getElementById('ins-aprovechamiento').value='95';
      document.getElementById('ins-save-btn').innerText='Guardar Insumo';
      toggleDirectCostFields();
    }

    function editInsumo(id) {
      const ins = appState.insumos.find(i=>i.id===id); if(!ins)return;
      document.getElementById('ins-edit-id').value=ins.id;
      document.getElementById('ins-nombre').value=ins.nombre||'';
      document.getElementById('ins-categoria').value=ins.categoria||'Otros';
      document.getElementById('ins-proveedor').value=ins.proveedor||'';
      document.getElementById('ins-contacto-prov').value=ins.contacto||'';
      document.getElementById('ins-unidad-compra').value=ins.unidadCompra||'pza';
      document.getElementById('ins-costo-tipo').value=ins.costoModo||'conversion';
      document.getElementById('ins-costo').value=ins.costoCompra ?? '';
      document.getElementById('ins-contenido').value=ins.contenidoPresentacion ?? ((ins.factor&&ins.unidadCompra!=='pza')?ins.factor:1);
      document.getElementById('ins-costo-directo').value=ins.costoDirecto ?? '';
      document.getElementById('ins-aprovechamiento').value=getInsumoAprovechamiento(ins);
      document.getElementById('ins-save-btn').innerText='Actualizar Insumo'; toggleDirectCostFields();
      switchTab('insumos'); window.scrollTo({top:0,behavior:'smooth'});
    }

    function saveInsumo() {
      const id=document.getElementById('ins-edit-id').value;
      const nombre=document.getElementById('ins-nombre').value.trim(), categoria=document.getElementById('ins-categoria').value, proveedor=document.getElementById('ins-proveedor').value.trim(), contacto=document.getElementById('ins-contacto-prov').value.trim(), unidadCompra=document.getElementById('ins-unidad-compra').value, modo=document.getElementById('ins-costo-tipo').value;
      const aprovechamiento=Math.max(0,Math.min(100,parseFloat(document.getElementById('ins-aprovechamiento').value)||0));
      const costoCompra=parseFloat(document.getElementById('ins-costo').value)||0, contenido=parseFloat(document.getElementById('ins-contenido').value)||0, costoDirecto=parseFloat(document.getElementById('ins-costo-directo').value)||0;
      if(!nombre){alert('Escribe el nombre del insumo.');return;}
      if(modo==='directo' && costoDirecto<=0){alert('Ingresa un costo directo por unidad de uso.');return;}
      if(modo==='conversion' && (costoCompra<=0||contenido<=0)){alert('Ingresa precio de compra y contenido de la presentación.');return;}
      const factor = unidadCompra==='kg'||unidadCompra==='l' ? 1000 : 1;
      const unidadBase = unidadCompra==='kg'?'g':unidadCompra==='l'?'ml':'pza';
      const costoPorUnidadUso = modo==='directo' ? costoDirecto : (costoCompra / Math.max(0.0001, contenido * factor)) / Math.max(0.0001,aprovechamiento/100);
      const data={nombre,categoria,proveedor:proveedor||'Proveedor General',contacto,unidadCompra,unidadBase,factor,contenidoPresentacion:contenido,costoCompra, costoModo:modo,costoDirecto:modo==='directo'?costoDirecto:null,costoPorUnidadUso,aprovechamiento,merma:100-aprovechamiento};
      if(id){const ins=appState.insumos.find(i=>i.id===id);if(ins)Object.assign(ins,data);}else{appState.insumos.push(Object.assign({id:'ins_'+Date.now()},data));}
      saveToStorage(); renderInsumos(); resetInsumoForm(); alert(id?'Insumo actualizado correctamente.':'Insumo registrado correctamente.');
    }

    function deleteInsumo(id) { const ins=appState.insumos.find(i=>i.id===id); if(!ins||!confirm('¿Eliminar "'+ins.nombre+'"? Las recetas que lo usen quedarán sin referencia.'))return; appState.insumos=appState.insumos.filter(i=>i.id!==id); saveToStorage(); renderInsumos(); renderRecipesTable(); }

    // --- MÓDULO 1B: RECETAS / FICHAS TÉCNICAS ---
    function calculateRecipeCost(recipe) {
      if (!recipe || !Array.isArray(recipe.ingredientes)) return 0;
      return recipe.ingredientes.reduce(function(total, ing) {
        const ins = appState.insumos.find(function(i) { return i.id === ing.insumoId; });
        return total + (ins ? getInsumoUnitCost(ins) * (Number(ing.cantidad) || 0) : 0);
      }, 0);
    }

    function calculateCurrentRecipeCost() {
      const temp = { ingredientes: currentRecipeIngredients };
      const cost = calculateRecipeCost(temp);
      const price = parseFloat(document.getElementById('rec-precio').value) || 0;
      const margin = price - cost;
      const pct = price > 0 ? (cost / price) * 100 : 0;
      document.getElementById('rec-live-cost').innerText = '$' + cost.toFixed(2);
      document.getElementById('rec-live-margin').innerText = '$' + margin.toFixed(2);
      document.getElementById('rec-live-foodcost-pct').innerText = pct.toFixed(1) + '%';
      return cost;
    }

    function renderRecipeIngredientsTable() {
      const tbody = document.getElementById('recipe-ingredients-table');
      if (!tbody) return;
      if (!currentRecipeIngredients.length) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:1.5rem;">No hay ingredientes agregados.</td></tr>';
        calculateCurrentRecipeCost();
        return;
      }
      tbody.innerHTML = '';
      currentRecipeIngredients.forEach(function(ing, idx) {
        const ins = appState.insumos.find(function(i) { return i.id === ing.insumoId; });
        if (!ins) return;
        const unitCost = getInsumoUnitCost(ins);
        const subtotal = unitCost * (Number(ing.cantidad) || 0);
        tbody.innerHTML += '<tr>' +
          '<td><strong>' + ins.nombre + '</strong></td>' +
          '<td class="font-mono">' + Number(ing.cantidad).toFixed(2) + '</td>' +
          '<td>' + ins.unidadBase + '</td>' +
          '<td class="font-mono" style="text-align:right;">$' + subtotal.toFixed(2) + '</td>' +
          '<td style="text-align:center;"><button class="btn btn-danger btn-sm" onclick="removeIngredientFromCurrentRecipe(' + idx + ')">✕</button></td>' +
        '</tr>';
      });
      calculateCurrentRecipeCost();
    }

    function addIngredientToCurrentRecipe(event) {
      if (event && typeof event.preventDefault === 'function') event.preventDefault();
      const select = document.getElementById('rec-select-insumo');
      const qtyInput = document.getElementById('rec-cant-insumo');
      const insumoId = select ? select.value : '';
      const cantidad = qtyInput ? parseFloat(qtyInput.value) : NaN;
      let resolvedId = insumoId;
      if (!resolvedId) {
        const q = (document.getElementById('rec-search-insumo')?.value || '').trim().toLowerCase();
        const matches = q ? appState.insumos.filter(i => String(i.nombre||'').toLowerCase().includes(q)) : [];
        if (matches.length === 1) resolvedId = matches[0].id;
      }
      if (!resolvedId || !isFinite(cantidad) || cantidad <= 0) {
        alert('Selecciona un insumo de la lista e ingresa una cantidad válida.');
        return;
      }
      const existing = currentRecipeIngredients.find(function(i) { return i.insumoId === resolvedId; });
      if (existing) existing.cantidad += cantidad;
      else currentRecipeIngredients.push({ insumoId: resolvedId, cantidad: cantidad });
      document.getElementById('rec-cant-insumo').value = '';
      renderRecipeIngredientsTable();
    }

    function removeIngredientFromCurrentRecipe(index) {
      currentRecipeIngredients.splice(index, 1);
      renderRecipeIngredientsTable();
    }

    function resetRecipeForm() {
      editingRecipeId = null;
      currentRecipeIngredients = [];
      document.getElementById('recipe-form-title').innerText = 'Crear / Editar Ficha Técnica';
      document.getElementById('rec-nombre').value = '';
      document.getElementById('rec-precio').value = '';
      document.getElementById('rec-ventas').value = '';
      document.getElementById('rec-rendimiento').value = '1';
      document.getElementById('rec-procedimiento').value = '';
      document.getElementById('rec-notas').value = '';
      document.getElementById('rec-categoria').selectedIndex = 0;
      document.getElementById('rec-cant-insumo').value = '';
      renderRecipeIngredientsTable();
    }
