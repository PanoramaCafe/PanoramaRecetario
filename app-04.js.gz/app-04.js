            const incoming = {
              categoria: cat,
              proveedor: sup && sup.name ? sup.name : 'Proveedor General',
              contacto: sup && sup.contact ? sup.contact : '',
              unidadCompra: product.purchaseUnit || 'pza',
              costoCompra: hasPurchasePrice ? purchasePrice : (hasCost ? importedCost : 0),
              costoPorUnidadUso: hasCost ? importedCost / ((['l','kg'].includes(String(product.purchaseUnit || '').toLowerCase()) && ['l','lt','litro','litros','kg','kilogramo','kilogramos'].includes(String(product.unit || '').toLowerCase())) ? 1000 : 1) : 0,
              costoModo: hasCost ? 'inventario' : 'conversion',
              aprovechamiento: 100,
              merma: 0,
              unidadBase: product.unit || 'pza',
              factor: 1,
              stockActual: Number(product.stock) || 0,
              stockMin: product.minStock === '' || product.minStock == null ? 0 : (Number(product.minStock) || 0),
              unidadUso: product.unit || '',
              precioCompraPresentacion: hasPurchasePrice ? purchasePrice : null,
              origenInventario: true,
              inventarioProductId: product.id || ''
            };

            const existing = appState.insumos.find(function(i) {
              return normalize(i.nombre) === normalize(name);
            });

            if (existing) {
              existing.categoria = incoming.categoria;
              existing.proveedor = incoming.proveedor;
              existing.contacto = incoming.contacto;
              existing.unidadCompra = incoming.unidadCompra;
              existing.costoCompra = incoming.costoCompra;
              existing.costoPorUnidadUso = incoming.costoPorUnidadUso;
              existing.costoModo = incoming.costoModo;
              existing.aprovechamiento = incoming.aprovechamiento;
              existing.merma = incoming.merma;
              existing.unidadBase = incoming.unidadBase;
              existing.factor = incoming.factor;
              existing.stockActual = incoming.stockActual;
              existing.stockMin = incoming.stockMin;
              existing.unidadUso = incoming.unidadUso;
              existing.precioCompraPresentacion = incoming.precioCompraPresentacion;
              existing.origenInventario = true;
              existing.inventarioProductId = incoming.inventarioProductId;
              updated++;
            } else {
              appState.insumos.push(Object.assign({ id: 'ins_' + Date.now() + '_' + Math.random().toString(36).slice(2,7), nombre: name }, incoming));
              created++;
            }
          });

          saveToStorage();
          renderInsumos();
          renderRecipesTable();
          updateSummaryCounts();
          if (status) status.innerText = '✓ ' + created + ' nuevos · ' + updated + ' actualizados. Costo de unidad de uso importado sin recalcular.';
          alert('Inventario importado correctamente.\n\nNuevos: ' + created + '\nActualizados: ' + updated + '\n\nTus recetas existentes no fueron reemplazadas.');
          input.value = '';
        } catch (err) {
          console.error(err);
          alert('No se pudo leer el respaldo de inventario: ' + err.message);
        }
      };
      reader.readAsText(file);
    }

    function processImportFile() {
      const fileInput = document.getElementById('file-import-input');
      if (!fileInput.files || fileInput.files.length === 0) {
        alert('Por favor selecciona un archivo (.csv o .json) para importar.');
        return;
      }

      const file = fileInput.files[0];
      const reader = new FileReader();

      reader.onload = function(e) {
        const text = e.target.result;

        if (file.name.toLowerCase().endsWith('.json')) {
          try {
            const parsed = JSON.parse(text);
            // Backup propio del Recetario: reemplaza solo si tiene la estructura exacta.
            if (parsed.insumos && parsed.recetas) {
              appState = {
                insumos: Array.isArray(parsed.insumos) ? parsed.insumos : [],
                recetas: Array.isArray(parsed.recetas) ? parsed.recetas : [],
                comprasGuardadas: Array.isArray(parsed.comprasGuardadas) ? parsed.comprasGuardadas : []
              };
              saveToStorage();
              renderInsumos();
              renderRecipesTable();
              alert('¡Backup del Recetario restaurado! Se cargaron ' + appState.insumos.length + ' insumos y ' + appState.recetas.length + ' recetas.');
              return;
            }
            // Si es un backup de Panorama Inventario, lo enviamos al importador puente.
            if (Array.isArray(parsed.products)) {
              importInventoryObject(parsed);
              return;
            }
          } catch(err) {
            alert('Error al leer el archivo JSON: formato inválido.');
            return;
          }
        }

        try {
          const lines = text.split(/\r\n|\n/).filter(function(l) { return l.trim().length > 0; });
          if (lines.length <= 1) {
            alert('El archivo CSV está vacío.');
            return;
          }

          let addedCount = 0;
          const separator = lines[0].includes(';') ? ';' : ',';

          for (let i = 1; i < lines.length; i++) {
            const cols = lines[i].split(separator).map(function(c) { return c.replace(/^"|"$/g, '').trim(); });
            if (cols.length >= 6) {
              const nombre = cols[0];
              const categoria = cols[1] || 'Abarrotes & Especias';
              const proveedor = cols[2] || 'General';
              const contacto = cols[3] || '';
              const unidadCompra = cols[4] || 'pza';
              const costo = parseFloat(cols[5]) || 0;
              const merma = cols[6] ? parseFloat(cols[6]) : 0;
              const stockMin = cols[7] ? parseFloat(cols[7]) : 2;

              if (nombre && !isNaN(costo)) {
                const factor = (unidadCompra === 'kg' || unidadCompra === 'l') ? 1000 : 1;
                const unidadBase = (unidadCompra === 'kg') ? 'g' : (unidadCompra === 'l') ? 'ml' : 'pza';

                appState.insumos.push({
                  id: 'ins_' + Date.now() + '_' + i,
                  nombre: nombre,
                  categoria: categoria,
                  proveedor: proveedor,
                  contacto: contacto,
                  unidadCompra: unidadCompra,
                  costoCompra: costo,
                  merma: merma,
                  unidadBase: unidadBase,
                  factor: factor,
                  stockActual: 0,
                  stockMin: stockMin
                });
                addedCount++;
              }
            }
          }

          saveToStorage();
          renderInsumos();
          renderRecipesTable();
          alert('¡Importación completada! Se agregaron ' + addedCount + ' nuevos insumos al inventario.');
          fileInput.value = '';
        } catch(err) {
          alert('Error al procesar el archivo CSV: ' + err.message);
        }
      };

      reader.readAsText(file);
    }

    function importInventoryObject(parsed) {
      const categories = Array.isArray(parsed.categories) ? parsed.categories : [];
      const suppliers = Array.isArray(parsed.suppliers) ? parsed.suppliers : [];
      const catNameById = function(id) { const c=categories.find(function(x){return x.id===id;}); return c&&c.name?c.name:'Sin Categoría'; };
      const supById = function(id) { return suppliers.find(function(x){return x.id===id;}) || null; };
      const norm = function(v){ return String(v||'').trim().toLowerCase(); };
      let created=0, updated=0;
      parsed.products.forEach(function(p){
        const name=String(p.name||'').trim(); if(!name) return;
        const s=supById(p.supplierId);
        const existing=appState.insumos.find(function(i){return norm(i.nombre)===norm(name);});
        const incoming={
          categoria:catNameById(p.categoryId), proveedor:s&&s.name?s.name:'Proveedor General', contacto:s&&s.contact?s.contact:'',
          unidadCompra:p.purchaseUnit||'pza', costoCompra:Number.isFinite(Number(p.purchasePrice))?Number(p.purchasePrice):(Number(p.cost)||0),
          costoPorUnidadUso:Number(p.cost)||0, merma:0, unidadBase:p.unit||'pza', factor:1,
          stockActual:Number(p.stock)||0, stockMin:p.minStock===''||p.minStock==null?0:(Number(p.minStock)||0),
          unidadUso:p.unit||'', precioCompraPresentacion:Number.isFinite(Number(p.purchasePrice))?Number(p.purchasePrice):null,
          origenInventario:true, inventarioProductId:p.id||''
        };
        if(existing){ Object.assign(existing,incoming); updated++; }
        else { appState.insumos.push(Object.assign({id:'ins_'+Date.now()+'_'+Math.random().toString(36).slice(2,7),nombre:name},incoming)); created++; }
      });
      saveToStorage(); renderInsumos(); renderRecipesTable(); updateSummaryCounts();
      alert('Inventario importado correctamente.\n\nNuevos: '+created+'\nActualizados: '+updated+'\n\nTus recetas existentes no fueron reemplazadas.');
    }

    function exportBackupJSON() {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(appState, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", "backup_recetario_completo.json");
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    }

    function downloadFile(content, fileName, mimeType) {
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

    // --- HISTORIAL MODAL ---
    function viewHistory(id) {
      const rec = appState.recetas.find(function(r) { return r.id === id; });
      if (!rec) return;
      document.getElementById('history-product-title').innerText = 'Historial: ' + rec.nombre;
      const container = document.getElementById('history-list');
      container.innerHTML = '';

      (rec.historial || []).forEach(function(h, idx) {
        const prev = rec.historial[idx - 1];
        let diffText = '';
        if (prev) {
          const diff = h.costo - prev.costo;
          const diffPct = prev.costo > 0 ? ((diff / prev.costo) * 100).toFixed(1) : '0';
          diffText = diff >= 0 
            ? '<span class="font-mono" style="color: var(--status-danger-text);">🔺 +$' + diff.toFixed(2) + ' (+' + diffPct + '%)</span>' 
            : '<span class="font-mono" style="color: var(--status-success-text);">🔻 -$' + Math.abs(diff).toFixed(2) + ' (' + diffPct + '%)</span>';
        }
        container.innerHTML += '<div class="history-item">' +
          '<div style="display: flex; justify-content: space-between; font-weight: 700;">' +
            '<span class="font-mono">📅 ' + h.fecha + '</span>' +
            '<span>Costo: <span class="font-mono">$' + h.costo.toFixed(2) + '</span> ' + diffText + '</span>' +
          '</div>' +
          '<div style="color: var(--text-muted); margin-top: 0.25rem;">' +
            'Precio venta: <span class="font-mono">$' + h.precio.toFixed(2) + '</span> | Motivo: ' + (h.motivo || 'Actualización') +
          '</div>' +
        '</div>';
      });

      document.getElementById('history-modal').style.display = 'flex';
    }

    function closeHistoryModal() {
      document.getElementById('history-modal').style.display = 'none';
    }

    // --- MATRIZ BCG ---
    function renderBCGMatrix() {
      if (!appState.recetas || appState.recetas.length === 0) return;

      let totalMarginTimesUnits = 0;
      let totalUnits = 0;
      let totalProfit = 0;

      const analyzed = appState.recetas.map(function(rec) {
        const cost = calculateRecipeCost(rec);
        const margin = rec.precio - cost;
        const profit = margin * rec.ventas;
        totalMarginTimesUnits += margin * rec.ventas;
        totalUnits += rec.ventas;
        totalProfit += profit;
        return { id: rec.id, nombre: rec.nombre, precio: rec.precio, ventas: rec.ventas, cost: cost, margin: margin, profit: profit };
      });

      const avgMargin = totalUnits > 0 ? totalMarginTimesUnits / totalUnits : 0;
      const avgPop = (totalUnits / analyzed.length) * 0.7;

      document.getElementById('bcg-avg-margin').innerText = '$' + avgMargin.toFixed(2);
      document.getElementById('bcg-avg-pop').innerText = Math.round(avgPop) + ' uds';
      document.getElementById('bcg-total-profit').innerText = '$' + totalProfit.toLocaleString('es-MX', { minimumFractionDigits: 2 });

      const stars = [];
      const plowhorses = [];
      const puzzles = [];
      const dogs = [];

      analyzed.forEach(function(item) {
        const isHighMargin = item.margin >= avgMargin;
        const isHighPop = item.ventas >= avgPop;

        if (isHighMargin && isHighPop) stars.push(item);
        else if (!isHighMargin && isHighPop) plowhorses.push(item);
        else if (isHighMargin && !isHighPop) puzzles.push(item);
        else dogs.push(item);
      });

      document.getElementById('count-stars').innerText = stars.length;
      document.getElementById('count-plowhorses').innerText = plowhorses.length;
      document.getElementById('count-puzzles').innerText = puzzles.length;
      document.getElementById('count-dogs').innerText = dogs.length;

      renderQuadrantList('list-stars', stars, 'Proteger receta y visibilidad.');
      renderQuadrantList('list-plowhorses', plowhorses, 'Subir precio gradualmente.');
      renderQuadrantList('list-puzzles', puzzles, 'Impulsar con meseros.');
      renderQuadrantList('list-dogs', dogs, 'Evaluar retiro de carta.');

      const optSelect = document.getElementById('opt-select-product');
      optSelect.innerHTML = '<option value="">-- Seleccionar producto --</option>';
      plowhorses.forEach(function(p) {
        optSelect.innerHTML += '<option value="' + p.id + '">' + p.nombre + ' (Precio: $' + p.precio + ', Margen: $' + p.margin.toFixed(2) + ')</option>';
      });
    }

    function renderQuadrantList(elementId, items, tip) {
      const el = document.getElementById(elementId);
      if (items.length === 0) {
        el.innerHTML = '<div style="color: var(--text-muted); padding: 0.5rem 0; font-size: 0.8rem;">Ningún producto en este cuadrante.</div>';
        return;
      }
      let html = '<div style="color: var(--text-muted); font-size: 0.75rem; margin-bottom: 0.6rem;">💡 ' + tip + '</div>';
      items.forEach(function(i) {
        html += '<div style="background: var(--bg-subtle); padding: 0.55rem 0.75rem; border-radius: 0.5rem; margin-bottom: 0.4rem; display: flex; justify-content: space-between; border: 1px solid var(--border-subtle);">' +
          '<strong>' + i.nombre + '</strong>' +
          '<span class="font-mono" style="font-weight: 700;">$' + i.margin.toFixed(2) + ' <span style="color: var(--text-muted); font-size: 0.75rem;">(' + i.ventas + 'u)</span></span>' +
        '</div>';
      });
      el.innerHTML = html;
    }

    function runOptimizationSimulation() {
      const recId = document.getElementById('opt-select-product').value;
      const rec = appState.recetas.find(function(r) { return r.id === recId; });
      if (!rec) {
        document.getElementById('opt-results').innerHTML = '<div style="text-align: center; color: var(--text-muted); padding: 1.5rem; background: var(--bg-subtle); border-radius: 0.75rem;">Selecciona un producto para simular.</div>';
        return;
      }

      const cost = calculateRecipeCost(rec);
      const simPriceInput = document.getElementById('opt-sim-price');
      if (!simPriceInput.value) simPriceInput.value = Math.ceil(rec.precio * 1.12);

      const simPrice = parseFloat(simPriceInput.value) || rec.precio;
      const costReductionPct = (parseFloat(document.getElementById('opt-cost-reduction').value) || 0) / 100;
      const optimizedCost = cost * (1 - costReductionPct);

      const elasticity = -0.75;
      const priceChangePct = (simPrice - rec.precio) / rec.precio;
      const salesChangePct = elasticity * priceChangePct;
      const projectedSales = Math.max(0, Math.round(rec.ventas * (1 + salesChangePct)));

      const currentMargin = rec.precio - cost;
      const newMargin = simPrice - optimizedCost;
      const currentProfit = rec.ventas * currentMargin;
      const newProfit = projectedSales * newMargin;
      const netGain = newProfit - currentProfit;

      document.getElementById('opt-results').innerHTML = '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 0.85rem; text-align: center;">' +
        '<div style="background: var(--bg-card); border: 1px solid var(--border-subtle); padding: 1rem; border-radius: 0.75rem;">' +
          '<div style="font-size: 0.7rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Nuevo Margen Unitario</div>' +
          '<div class="font-mono" style="font-size: 1.25rem; font-weight: 900; color: var(--status-success-text); margin-top: 0.25rem;">$' + newMargin.toFixed(2) + '</div>' +
        '</div>' +
        '<div style="background: var(--bg-card); border: 1px solid var(--border-subtle); padding: 1rem; border-radius: 0.75rem;">' +
          '<div style="font-size: 0.7rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Ventas Proyectadas</div>' +
          '<div class="font-mono" style="font-size: 1.25rem; font-weight: 900; color: var(--text-main); margin-top: 0.25rem;">' + projectedSales + ' uds <span style="font-size: 0.7rem; color: var(--status-danger-text);">(' + Math.round(salesChangePct * 100) + '%)</span></div>' +
        '</div>' +
        '<div style="background: var(--bg-card); border: 1px solid var(--border-subtle); padding: 1rem; border-radius: 0.75rem;">' +
          '<div style="font-size: 0.7rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Ganancia Mensual Neta</div>' +
          '<div class="font-mono" style="font-size: 1.25rem; font-weight: 900; color: ' + (netGain >= 0 ? 'var(--status-success-text)' : 'var(--status-danger-text)') + '; margin-top: 0.25rem;">' +
            (netGain >= 0 ? '+' : '') + '$' + netGain.toFixed(2) + ' MXN' +
          '</div>' +
        '</div>' +
      '</div>';
    }

    // Inicialización general
    window.addEventListener('DOMContentLoaded', function() {
      renderInsumos();
      renderRecipesTable();
      renderInsumoOptions();
      updateSummaryCounts();
    });
  