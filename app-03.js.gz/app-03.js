
    function openPurchaseOrderPdfModal(po) {
      let rowsHtml = '';
      po.articulos.forEach(function(item, idx) {
        rowsHtml += '<tr style="border-bottom: 1px solid #e7e5e4;">' +
          '<td class="font-mono" style="padding: 8px 12px; color: #78716c; text-align: center;">' + (idx + 1) + '</td>' +
          '<td style="padding: 8px 12px; font-weight: 700; color: #1c1917;">' + item.nombre + '<br><span style="font-size: 0.72rem; color: #78716c;">' + item.categoria + '</span></td>' +
          '<td style="padding: 8px 12px; color: #44403c;">' + item.proveedor + '</td>' +
          '<td class="font-mono" style="padding: 8px 12px; text-align: center; font-weight: 800; font-size: 1rem;">' + item.cantidad + ' ' + item.unidad + '</td>' +
          '<td class="font-mono" style="padding: 8px 12px; text-align: right;">$' + Number(item.costoUnit).toFixed(2) + '</td>' +
          '<td class="font-mono" style="padding: 8px 12px; text-align: right; font-weight: 800; color: #1c1917;">$' + Number(item.subtotal).toFixed(2) + '</td>' +
          '<td style="padding: 8px 12px; text-align: center; color: #a8a29e; font-size: 1.1rem;">[ &nbsp; ]</td>' +
        '</tr>';
      });

      const modalContent = '<div style="font-family: var(--font-sans); color: #1c1917; line-height: 1.5;">' +
        '<div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #1c1917; padding-bottom: 12px; margin-bottom: 16px;">' +
          '<div>' +
            '<h1 style="font-size: 1.5rem; font-weight: 900; margin: 0; color: #1c1917; letter-spacing: -0.02em;">ORDEN & LISTA DE COMPRAS</h1>' +
            '<p style="font-size: 0.85rem; color: #78716c; margin: 4px 0 0 0;">' + po.titulo + '</p>' +
          '</div>' +
          '<div style="text-align: right; font-size: 0.8rem; color: #78716c;">' +
            '<div><strong>Folio:</strong> <span class="font-mono">' + po.id + '</span></div>' +
            '<div><strong>Fecha:</strong> <span class="font-mono">' + po.fecha + '</span></div>' +
          '</div>' +
        '</div>' +
        '<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px; background: #fcfbf9; padding: 14px; border-radius: 12px; border: 1px solid #e7e5e4;">' +
          '<div style="text-align: center;">' +
            '<div style="font-size: 0.7rem; color: #78716c; font-weight: 700; text-transform: uppercase;">Proveedor / Destino</div>' +
            '<div style="font-size: 1rem; font-weight: 800; color: #1c1917; margin-top: 2px;">' + (po.proveedorHeader || 'General') + '</div>' +
          '</div>' +
          '<div style="text-align: center;">' +
            '<div style="font-size: 0.7rem; color: #78716c; font-weight: 700; text-transform: uppercase;">Total Partidas</div>' +
            '<div class="font-mono" style="font-size: 1.25rem; font-weight: 900; color: #1c1917; margin-top: 2px;">' + po.articulos.length + '</div>' +
          '</div>' +
          '<div style="text-align: center;">' +
            '<div style="font-size: 0.7rem; color: #78716c; font-weight: 700; text-transform: uppercase;">Total Estimado Compra</div>' +
            '<div class="font-mono" style="font-size: 1.25rem; font-weight: 900; color: #065f46; margin-top: 2px;">$' + Number(po.totalEstimado).toFixed(2) + ' MXN</div>' +
          '</div>' +
        '</div>' +
        '<table style="width: 100%; border-collapse: collapse; font-size: 0.85rem; margin-bottom: 20px;">' +
          '<thead>' +
            '<tr style="background: #f5f5f4; border-bottom: 2px solid #e7e5e4;">' +
              '<th style="padding: 8px 12px; text-align: center; width: 40px; color: #78716c;">#</th>' +
              '<th style="padding: 8px 12px; text-align: left; color: #78716c;">Insumo</th>' +
              '<th style="padding: 8px 12px; text-align: left; color: #78716c;">Proveedor</th>' +
              '<th style="padding: 8px 12px; text-align: center; color: #78716c;">Cantidad</th>' +
              '<th style="padding: 8px 12px; text-align: right; color: #78716c;">Costo Unit.</th>' +
              '<th style="padding: 8px 12px; text-align: right; color: #78716c;">Subtotal</th>' +
              '<th style="padding: 8px 12px; text-align: center; width: 60px; color: #78716c;">Check</th>' +
            '</tr>' +
          '</thead>' +
          '<tbody>' + rowsHtml + '</tbody>' +
          '<tfoot>' +
            '<tr style="background: #fcfbf9; font-weight: 800; border-top: 2px solid #e7e5e4;">' +
              '<td colspan="5" style="padding: 10px 12px; text-align: right;">TOTAL ESTIMADO DE LA ORDEN:</td>' +
              '<td class="font-mono" style="padding: 10px 12px; text-align: right; font-size: 1.1rem; color: #065f46;">$' + Number(po.totalEstimado).toFixed(2) + '</td>' +
              '<td></td>' +
            '</tr>' +
          '</tfoot>' +
        '</table>' +
        '<div style="margin-top: 2rem; display: flex; justify-content: space-between; font-size: 0.75rem; color: #78716c; border-top: 1px dashed #e7e5e4; padding-top: 1rem;">' +
          '<div>Firma de Autorización / Encargado: ____________________</div>' +
          '<div>Fecha de Recepción: ____ / ____ / ________</div>' +
        '</div>' +
      '</div>';

      document.getElementById('printable-purchase-order').innerHTML = modalContent;
      document.getElementById('po-pdf-modal').style.display = 'flex';
    }

    function closePdfModal() {
      document.getElementById('pdf-modal').style.display = 'none';
    }

    function closePoPdfModal() {
      document.getElementById('po-pdf-modal').style.display = 'none';
    }

    function buildRecipePrintHtml(rec) {
      const cost = calculateRecipeCost(rec);
      const margin = (Number(rec.precio) || 0) - cost;
      const foodPct = rec.precio > 0 ? (cost / rec.precio) * 100 : 0;
      let rows = '';
      (rec.ingredientes || []).forEach(function(ing) {
        const ins = appState.insumos.find(function(i) { return i.id === ing.insumoId; });
        if (!ins) return;
        const unitCost = getInsumoUnitCost(ins);
        rows += '<tr><td>' + ins.nombre + '</td><td>' + Number(ing.cantidad || 0).toFixed(2) + '</td><td>' + (ins.unidadBase || '') + '</td><td>$' + unitCost.toFixed(4) + '</td><td>$' + (unitCost * Number(ing.cantidad || 0)).toFixed(2) + '</td></tr>';
      });
      return '<div style="font-family:Arial,sans-serif;max-width:900px;margin:0 auto;padding:20px;">' +
        '<h1 style="margin-bottom:4px;">' + rec.nombre + '</h1><div style="color:#666;margin-bottom:18px;">' + (rec.categoria || '') + ' · Rendimiento: ' + (rec.rendimiento || 1) + '</div>' +
        '<table style="width:100%;border-collapse:collapse;margin-bottom:18px;"><thead><tr><th style="text-align:left;border-bottom:1px solid #ccc;padding:7px;">Ingrediente</th><th style="text-align:left;border-bottom:1px solid #ccc;padding:7px;">Cantidad</th><th style="text-align:left;border-bottom:1px solid #ccc;padding:7px;">Unidad</th><th style="text-align:right;border-bottom:1px solid #ccc;padding:7px;">Costo unit.</th><th style="text-align:right;border-bottom:1px solid #ccc;padding:7px;">Subtotal</th></tr></thead><tbody>' + rows + '</tbody></table>' +
        '<div style="display:flex;gap:24px;flex-wrap:wrap;margin:15px 0;"><strong>Costo: $' + cost.toFixed(2) + '</strong><strong>Precio: $' + Number(rec.precio || 0).toFixed(2) + '</strong><strong>Food Cost: ' + foodPct.toFixed(1) + '%</strong><strong>Margen: $' + margin.toFixed(2) + '</strong></div>' +
        (rec.procedimiento ? '<h2>Preparación</h2><p style="white-space:pre-wrap;line-height:1.5;">' + rec.procedimiento + '</p>' : '') +
        (rec.notas ? '<h2>Notas / estándar</h2><p style="white-space:pre-wrap;line-height:1.5;">' + rec.notas + '</p>' : '') +
      '</div>';
    }

    function viewRecipePdf(id) {
      const rec = appState.recetas.find(function(r) { return r.id === id; });
      if (!rec) return;
      document.getElementById('printable-escandallo').innerHTML = buildRecipePrintHtml(rec);
      document.getElementById('pdf-modal').style.display = 'flex';
    }

    function printAllRecipes() {
      if (!appState.recetas.length) { alert('No hay recetas para imprimir.'); return; }
      let html = '';
      appState.recetas.forEach(function(r, idx) { html += buildRecipePrintHtml(r); if (idx < appState.recetas.length - 1) html += '<div style="page-break-after:always;"></div>'; });
      document.getElementById('printable-escandallo').innerHTML = html;
      document.getElementById('pdf-modal').style.display = 'flex';
    }


    function renderAnalysis() {
      const rows=document.getElementById('analysis-table'), insights=document.getElementById('analysis-insights');
      if(!rows)return;
      const data=appState.recetas.map(r=>{const cost=calculateRecipeCost(r),price=Number(r.precio)||0,ventas=Number(r.ventas)||0,margin=price-cost,food=price>0?cost/price*100:0;return {r,cost,price,ventas,margin,food,profit:margin*ventas};}).sort((a,b)=>b.profit-a.profit);
      rows.innerHTML=data.length?data.map(x=>'<tr><td><strong>'+x.r.nombre+'</strong></td><td class="font-mono" style="text-align:right">$'+x.cost.toFixed(2)+'</td><td class="font-mono" style="text-align:right">$'+x.price.toFixed(2)+'</td><td class="font-mono" style="text-align:right">'+x.food.toFixed(1)+'%</td><td class="font-mono" style="text-align:right">$'+x.margin.toFixed(2)+'</td><td class="font-mono" style="text-align:right">'+x.ventas+'</td><td class="font-mono" style="text-align:right;font-weight:700">$'+x.profit.toFixed(2)+'</td></tr>').join(''):'<tr><td colspan="7" style="text-align:center;padding:1.5rem;color:var(--text-muted)">Crea recetas para ver el análisis.</td></tr>';
      const avgFood=data.length?data.reduce((a,x)=>a+x.food,0)/data.length:0,avgMargin=data.length?data.reduce((a,x)=>a+x.margin,0)/data.length:0,totalProfit=data.reduce((a,x)=>a+x.profit,0);
      document.getElementById('analysis-foodcost').innerText=avgFood.toFixed(1)+'%'; document.getElementById('analysis-margin').innerText='$'+avgMargin.toFixed(2); document.getElementById('analysis-profit').innerText='$'+totalProfit.toFixed(2);
      if(insights) insights.innerHTML=data.length?'<p>• <strong>Food Cost:</strong> identifica recetas cuyo costo de ingredientes consume demasiado del precio de venta.</p><p>• <strong>Margen de contribución:</strong> muestra cuánto deja cada venta antes de otros gastos.</p><p>• <strong>Ganancia bruta mensual estimada:</strong> margen × ventas mensuales capturadas.</p><p>• Usa la <strong>Matriz</strong> para cruzar popularidad y margen y decidir qué mantener, impulsar, ajustar o retirar.</p>':'Sin datos todavía.';
    }

    // --- MÓDULO 4: EXPORTACIÓN & IMPORTACIÓN ---
    function exportSingleRecipeExcel(id) {
      const rec = appState.recetas.find(function(r) { return r.id === id; });
      if (!rec) return;

      const cost = calculateRecipeCost(rec);
      const margin = rec.precio - cost;
      const foodCostPct = rec.precio > 0 ? (cost / rec.precio) * 100 : 0;

      let csv = "\uFEFF";
      csv += "FICHA TECNICA: " + rec.nombre.toUpperCase() + "\n";
      csv += "Categoria;" + rec.categoria + "\n";
      csv += "Precio de Venta ($);" + rec.precio.toFixed(2) + "\n";
      csv += "Costo Receta ($);" + cost.toFixed(2) + "\n";
      csv += "Margen Bruto ($);" + margin.toFixed(2) + "\n";
      csv += "Food Cost (%);" + foodCostPct.toFixed(2) + "%\n\n";

      csv += "DESGLOSE DE INGREDIENTES\n";
      csv += "Ingrediente;Categoria;Cantidad;Unidad Base;Merma (%);Costo Unitario ($);Costo Insumo ($);% del Costo\n";

      (rec.ingredientes || []).forEach(function(ing) {
        const ins = appState.insumos.find(function(i) { return i.id === ing.insumoId; });
        const unitCost = ins ? getInsumoUnitCost(ins) : 0;
        const totalIngCost = unitCost * ing.cantidad;
        const pct = cost > 0 ? (totalIngCost / cost) * 100 : 0;

        csv += '"' + (ins ? ins.nombre : 'Eliminado') + '";"' + (ins ? ins.categoria : '') + '";' + ing.cantidad + ';"' + (ins ? ins.unidadBase : '') + '";' + (ins ? ins.merma : 0) + '%;' + unitCost.toFixed(4) + ';' + totalIngCost.toFixed(2) + ';' + pct.toFixed(1) + '%\n';
      });

      csv += "\nTOTAL FOOD COST;;;;;;" + cost.toFixed(2) + ";100.0%\n";
      downloadFile(csv, "Escandallo_" + rec.nombre.replace(/\s+/g, '_') + ".csv", "text/csv;charset=utf-8;");
    }

    function exportInsumosCsv() {
      let csv = "\uFEFF";
      csv += "ID;Nombre;Categoria;Proveedor;Contacto;UnidadCompra;UnidadBase;CostoModo;CostoPorUnidadUso;AprovechamientoPct;PrecioCompra;ContenidoPresentacion\n";
      appState.insumos.forEach(function(i) {
        csv += '"' + i.id + '";"' + i.nombre + '";"' + (i.categoria || '') + '";"' + (i.proveedor || '') + '";"' + (i.contacto || '') + '";"' + i.unidadCompra + '";' + i.costoCompra + ';' + i.merma + ';"' + i.unidadBase + '";' + (i.stockActual || 0) + ';' + (i.stockMin || 0) + '\n';
      });
      downloadFile(csv, "Insumos_Inventario_" + new Date().toISOString().split('T')[0] + ".csv", "text/csv;charset=utf-8;");
    }

    function exportRecipesCsv() {
      let csv = "\uFEFF";
      csv += "ID;Producto;Categoria;PrecioVenta;VentasMes;CostoTotal;MargenBruto;FoodCostPct\n";
      appState.recetas.forEach(function(r) {
        const cost = calculateRecipeCost(r);
        const margin = r.precio - cost;
        const foodCostPct = r.precio > 0 ? (cost / r.precio) * 100 : 0;
        csv += '"' + r.id + '";"' + r.nombre + '";"' + r.categoria + '";' + r.precio.toFixed(2) + ';' + r.ventas + ';' + cost.toFixed(2) + ';' + margin.toFixed(2) + ';' + foodCostPct.toFixed(1) + '%\n';
      });
      downloadFile(csv, "Catalogo_Recetas_" + new Date().toISOString().split('T')[0] + ".csv", "text/csv;charset=utf-8;");
    }

    function exportMasterExcel() {
      let csv = "\uFEFF";
      csv += "LIBRO MAESTRO DE CAFETERIA: RECETAS, INVENTARIOS Y COMPRAS\n";
      csv += "Fecha de emision;" + new Date().toLocaleDateString('es-MX') + "\n\n";

      csv += "SECCION 1: CATALOGO DE RECETAS & ESCANDALLOS\n";
      csv += "ID;Producto;Categoria;Precio Venta ($);Costo Receta ($);Margen Bruto ($);Food Cost (%);Ventas Mensuales (Uds);Ganancia Mensual ($)\n";
      appState.recetas.forEach(function(r) {
        const cost = calculateRecipeCost(r);
        const margin = r.precio - cost;
        const foodCostPct = r.precio > 0 ? (cost / r.precio) * 100 : 0;
        const profit = margin * r.ventas;
        csv += '"' + r.id + '";"' + r.nombre + '";"' + r.categoria + '";' + r.precio.toFixed(2) + ';' + cost.toFixed(2) + ';' + margin.toFixed(2) + ';' + foodCostPct.toFixed(1) + '%;' + r.ventas + ';' + profit.toFixed(2) + '\n';
      });

      csv += "\n\nSECCION 2: INVENTARIO DE INSUMOS & PROVEEDORES\n";
      csv += "ID;Insumo;Categoria;Proveedor;Contacto;Presentacion;Costo Compra ($);Merma (%);Costo Neto Unidad Base ($);Stock Actual;Stock Minimo\n";
      appState.insumos.forEach(function(i) {
        const uCost = getInsumoUnitCost(i);
        csv += '"' + i.id + '";"' + i.nombre + '";"' + (i.categoria || '') + '";"' + (i.proveedor || '') + '";"' + (i.contacto || '') + '";"1 ' + i.unidadCompra + '";' + Number(i.costoCompra).toFixed(2) + ';' + i.merma + '%;' + uCost.toFixed(4) + ';' + (i.stockActual || 0) + ';' + (i.stockMin || 0) + '\n';
      });

      csv += "\n\nSECCION 3: HISTORIAL DE COMPRAS REGISTRADAS\n";
      csv += "Folio;Fecha;Titulo / Referencia;Proveedor;Numero Partidas;Total Estimado ($)\n";
      (appState.comprasGuardadas || []).forEach(function(po) {
        csv += '"' + po.id + '";"' + po.fecha + '";"' + po.titulo + '";"' + (po.proveedorHeader || '') + '";' + po.articulos.length + ';' + Number(po.totalEstimado).toFixed(2) + '\n';
      });

      downloadFile(csv, "Libro_Maestro_Cafeteria_" + new Date().toISOString().split('T')[0] + ".csv", "text/csv;charset=utf-8;");
    }

    function downloadInsumosTemplate() {
      let csv = "\uFEFF";
      csv += "Nombre;Categoria;Proveedor;Contacto;UnidadCompra;CostoCompra;MermaPct;StockMin\n";
      csv += "Café de Especialidad (Grano);Café & Granos;Finca San Agustín;951 112 3344;kg;320.00;3.0;3.0\n";
      csv += "Leche Entera;Lácteos & Bebidas;Lácteos de Oaxaca;951 223 4455;l;28.00;5.0;8.0\n";
      csv += "Vaso Desechable 12oz;Desechables & Empaque;Empaques del Sur;951 445 6677;pza;4.50;0.0;100.0\n";
      downloadFile(csv, "Plantilla_Importar_Insumos.csv", "text/csv;charset=utf-8;");
    }

    function importInventoryBackup() {
      const input = document.getElementById('inventory-import-input');
      const status = document.getElementById('inventory-import-status');
      if (!input || !input.files || input.files.length === 0) {
        alert('Selecciona primero el respaldo JSON de Panorama Inventario.');
        return;
      }
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = function(e) {
        try {
          const parsed = JSON.parse(e.target.result);
          if (!parsed || !Array.isArray(parsed.products)) {
            alert('Este archivo no parece ser un respaldo de Panorama Inventario.');
            return;
          }

          const categories = Array.isArray(parsed.categories) ? parsed.categories : [];
          const suppliers = Array.isArray(parsed.suppliers) ? parsed.suppliers : [];
          let created = 0, updated = 0;

          const categoryName = function(id) {
            const c = categories.find(function(x) { return x.id === id; });
            return c && c.name ? c.name : 'Sin Categoría';
          };
          const supplierData = function(id) {
            const s = suppliers.find(function(x) { return x.id === id; });
            return s || null;
          };
          const normalize = function(v) {
            return String(v || '').trim().toLowerCase();
          };

          parsed.products.forEach(function(product) {
            const name = String(product.name || '').trim();
            if (!name) return;

            const cat = categoryName(product.categoryId);
            const sup = supplierData(product.supplierId);
            const purchasePrice = Number(product.purchasePrice);
            const importedCost = Number(product.cost);
            const hasPurchasePrice = Number.isFinite(purchasePrice);
            const hasCost = Number.isFinite(importedCost);

            // El costo del inventario ya está expresado por unidad de uso.
            // Lo guardamos separado del precio de compra para que el Recetario
            // pueda mostrar ambos sin alterar el cálculo.
